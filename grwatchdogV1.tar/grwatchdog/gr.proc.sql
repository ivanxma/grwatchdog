delimiter //

use sys//

drop function if exists gr_is_member_online//
create function gr_is_member_online()
	returns boolean NOT DETERMINISTIC
	READS SQL DATA
BEGIN
	DECLARE ls_state VARCHAR(30) DEFAULT "";

	select m.MEMBER_STATE  into ls_state
	from performance_schema.global_variables a, performance_schema.replication_group_members m 
	where a.variable_name = 'server_uuid' and a.variable_value = m.member_id;

	IF ls_state = 'ONLINE' THEN
		RETURN(true);
	END IF;


	RETURN(false);
END;
//


drop function if exists gr_is_primary_member//

create function gr_is_primary_member()
	returns boolean NOT DETERMINISTIC
	READS SQL DATA
BEGIN
	DECLARE ls_pmember VARCHAR(64) DEFAULT "";
	DECLARE li_row INT DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET li_row=0;

	-- if status 'group_replication_primary_member' is empty value or
	-- 'group_replication_primary_member' is this member, return true
	-- else return false

	SELECT variable_value into ls_pmember 
	FROM performance_schema.global_status
	WHERE variable_name like 'group_replication_primary_member';

	IF ls_pmember = '' THEN
		return(true);
	END IF;


	SELECT 1 into li_row
	FROM performance_schema.global_variables v
	where v.variable_name = 'server_uuid' and v.variable_value = ls_pmember;

	IF li_row = 1 THEN
		RETURN(true);
	END IF;
	
	RETURN(false);

END;
//


drop function if exists gr_is_major_online_member//

create function gr_is_major_online_member()
	returns boolean NOT DETERMINISTIC
	READS SQL DATA
BEGIN
	DECLARE li_row INT DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET li_row=0;

	SELECT IF( MEMBER_STATE='ONLINE' AND 
		((SELECT COUNT(*) FROM performance_schema.replication_group_members 
		WHERE MEMBER_STATE != 'ONLINE') >= 
		((SELECT COUNT(*) FROM performance_schema.replication_group_members)/2) = 0), 1, 0 ) 
		INTO li_row
	FROM performance_schema.replication_group_members JOIN performance_schema.replication_group_member_stats USING(member_id);

	IF li_row = 1 THEN
		RETURN(true);
	END IF;
	
	RETURN(false);

END;
//


