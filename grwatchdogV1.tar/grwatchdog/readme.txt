Watchdog for Group Replication

It is a local process watching for the status of the running MySQL daemons.
Status Checking on
- Check the status :
if it is ONLINE
	- Check it is in the Majority Group of Minor Group
	- If it is in Majority Group, sleep for a defined interval
	- If it is in the minority Group, for now, it shutdown the server
		depending on the ACTION on Minority
		a. READ-ONLY
		b. SHUTDOWN

The gr_watchdog uses "login-path" from mysql_config_editor to access to the MySQL servers.   

Example:
./gr_watchdog.sh gr3306:gr3316:gr3326 60

The above command check the mysql login path "gr3306", "gr3316", "gr3326" at interval of 60 seconds.

To STOP :
#gr_watchdog.sh stop

OR 

Either "kill" the process

OR 

Remove the file "gr_watchdog.sh.stop" from the current folder.
The gr_watchdog will loop forever until the file "gr_watchdog.sh.stop" is removed from the current folder.


INSTALLATION & RUN
1. Run the gr.proc.sql on the Group of the Server (If they are in the Group Replication, running only once on One server in the Group).
2. Setup login_path using mysql_config_editor to connect to the Server(s).
3. Execute gr_watchdog.sh [start|stop]


SETUP configuration in gr_comm.sh
ACTION=[SHUTDOWN|READONLY]
RETRY_COUNT=3
QUIET_MODE=1

GRSERVERS=login_path:[login_path][:....]
GRINTERVAL=30










