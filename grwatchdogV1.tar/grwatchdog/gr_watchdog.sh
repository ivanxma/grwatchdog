# This program monitor the MySQL Server(s) in a Group Replication setup
# The monitored MySQL (mysqld) Server should be retain on the local machine with this program
#	If the Server is ONLINE and in Majority of the Group, it is normal
#	Otherwise, use mysqladmin shutdown to shutdown the process
#
PROG=`basename $0`

. ./gr_comm.sh

LOGFILE=$OUTDIR/$PROG.`date +"%Y%m%d"`.log
STOPFILE=$OUTDIR/$PROG.$$.stop

function usage()
{

	echo "usage : $PROG [start | stop]"
	echo "Please check the gr_comm.sh for the configuration"
}


if [ $# != 1 ]
then
	usage
	exit
fi

if [ "$1" == "stop" -o "$1" == "STOP" ]
then
	echo "Stopping $PROG"
	rm -f $OUTDIR/$PROG.*.stop
	sleep 5
	exit
fi

if [ "$1" != "start" -a "$1" != "START" ]
then
	usage
	exit
fi

	

MYSQL_LP=$GRSERVERS
SLEEP=$GRINTERVAL

echo "`date +"%Y%m%d-%H%M%S"`:[INFO] Group Replication watchdog running for Servers [$MYSQL_LP] at interval [$SLEEP]" | tee -a $LOGFILE

function log_msg()
{
	LOGFILE=$OUTDIR/$PROG.`date +"%Y%m%d"`.log
	if [ "$QUIET_MODE" -ne 1 ]
	then
		echo "`date +"%Y%m%d-%H%M%S"`:[INFO] $1" | tee -a $LOGFILE
	fi

}

function log_error()
{
	LOGFILE=$OUTDIR/$PROG.`date +"%Y%m%d"`.log
	echo "`date +"%Y%m%d-%H%M%S"`:[ERROR] $1 " |tee -a $LOGFILE
}

function clean_up()
{
	rm -f /tmp/grstatus.$$.*
	rm -f $OUTDIR/$PROG.$$.stop
	echo "bye"
}

function shutdown_mysqld()
{
	MYSQL_LOGIN_PATH=$1
	VARNAME=RETRY_$MYSQL_LOGIN_PATH
	THISCOUNT=`expr $THISCOUNT + 1`
	eval "$VARNAME=$THISCOUNT"
	if [ $THISCOUNT -ge $RETRY_COUNT ]
	then
		if [ $THISCOUNT -ne 101 ]
		then
			log_error "Shutting down the server...."
			mysqladmin --login-path=$MYSQL_LOGIN_PATH shutdown
			eval "$VARNAME=100"
		else
			log_msg "Shutdown server has been executed once-[$MYSQL_LOGIN_PATH]"
		fi
	else
		eval "$VARNAME=$THISCOUNT"
		log_msg "RETRYING Count [$THISCOUNT] / [$RETRY_COUNT]"
	fi
}

function readonly_mysqld()
{
	MYSQL_LOGIN_PATH=$1
	VARNAME=RETRY_$MYSQL_LOGIN_PATH
	eval "THISCOUNT=\$$VARNAME"
	THISCOUNT=`expr $THISCOUNT + 1`
	if [ $THISCOUNT -ge $RETRY_COUNT ]
	then
		if [ $THISCOUNT -ne 101 ]
		then
			log_error "setting Readonly mode on Server [$MYSQL_LOGIN_PATH)"
mysql --login-path=$MYSQL_LOGIN_PATH << EOL
		set global READ_ONLY=1;
		set global SUPER_READ_ONLY=1;
EOL

			eval "$VARNAME=100"
		else
			log_msg "setting READ-ONLY server has been executed once-[$MYSQL_LOGIN_PATH]"
		fi
	else
		eval "$VARNAME=$THISCOUNT"
		log_error "RETRYING Count [$THISCOUNT] / [$RETRY_COUNT]"
	fi
}

function restartgr_mysqld()
{
	MYSQL_LOGIN_PATH=$1
	VARNAME=RETRY_$MYSQL_LOGIN_PATH
	eval "THISCOUNT=\$$VARNAME"
	THISCOUNT=`expr $THISCOUNT + 1`
	if [ $THISCOUNT -ge $RETRY_COUNT ]
	then
		if [ $THISCOUNT -ne 101 ]
		then
			log_error "restarting GR on Server [$MYSQL_LOGIN_PATH)"
mysql --login-path=$MYSQL_LOGIN_PATH << EOL
		set global group_replication_bootstrap_group=OFF;
		stop group_replication;
		start group_replication;
EOL

			eval "$VARNAME=100"
		else
			log_msg "restarting GR on Server has been executed once-[$MYSQL_LOGIN_PATH]"
		fi
	else
		eval "$VARNAME=$THISCOUNT"
		log_error "RETRYING Count [$THISCOUNT] / [$RETRY_COUNT]"
	fi
}


trap "clean_up;exit" SIGHUP SIGINT SIGTERM SIGKILL SIGQUIT SIGABRT
touch $STOPFILE

for mypath in `echo $MYSQL_LP|tr ':' ' '`
do
		VARNAME=RETRY_$mypath
		eval "export $VARNAME=0"
done


while [ -r $STOPFILE ]
do

for mypath in `echo $MYSQL_LP|tr ':' ' '`
do

#echo "`date` - checking $mypath"

mysql --login-path=$mypath << EOL > /tmp/grstatus.$$.$mypath 2>&1

	select "$mypath" as path, sys.gr_is_major_online_member() as ONLINE \G
	SELECT @@hostname, @@port\G

EOL


MYERROR=`cat /tmp/grstatus.$$.$mypath|grep ERROR|wc -l`
if [ $MYERROR -eq 0 ]
then
	MYONLINE=`cat /tmp/grstatus.$$.$mypath|grep ONLINE|cut -f2 -d:|sed 's/ //g'`
	MYHOST=`cat /tmp/grstatus.$$.$mypath|grep hostname|cut -f2 -d:|sed 's/ //g'`
	MYPORT=`cat /tmp/grstatus.$$.$mypath|grep port|cut -f2 -d:|sed 's/ //g'`


	if [ "$MYONLINE" != "1" ]
	then
		log_error "Failure Server -[$MYHOST:$MYPORT]" 

		if [ "$ACTION" == "SHUTDOWN"  ]
		then
			shutdown_mysqld $mypath
		fi
		if [ "$ACTION" == "READONLY"  ]
		then
			readonly_mysqld $mypath
		fi
		if [ "$ACTION" == "RESTARTGR"  ]
		then
			restartgr_mysqld $mypath
		fi
	else
		log_msg "Server [$MYHOST:$MYPORT] is ONLINE"
		VARNAME=RETRY_$mypath
		eval "export $VARNAME=0"
	fi
else
	log_error "Error connecting to $mypath"
	cat /tmp/grstatus.$$.$mypath | tee $LOGFILE
fi

rm -f /tmp/grstatus.$$.$mypath


done
sleep $SLEEP
done

clean_up

