export MYSQL_HOME=/usr/local/mysql
export PATH=$MYSQL_HOME/bin:$PATH

# ACTION can be SHUTDOWN, READONLY
export ACTION=READONLY
export RETRY_COUNT=3
export QUIET_MODE=0


export GRSERVERS=gr3306:gr3316:gr3326
export GRINTERVAL=30
export OUTDIR=/home/mysql/demo/GroupReplication/grwatchdog/log

